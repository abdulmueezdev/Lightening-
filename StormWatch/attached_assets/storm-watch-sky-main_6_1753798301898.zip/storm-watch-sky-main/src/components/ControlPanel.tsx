import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, ZapOff, Activity, Clock, Target, Globe, Wifi, WifiOff, Loader2 } from 'lucide-react';

interface ControlPanelProps {
  isConnected: boolean;
  onConnect: () => void;
  onDisconnect: () => void;
  stats: {
    totalStrikes: number;
    strikeRate: number;
    filteredStrikes: number;
    uptime: string;
  };
  connectionStatus: 'disconnected' | 'connecting' | 'connected' | 'error';
}

const ControlPanel: React.FC<ControlPanelProps> = ({
  isConnected,
  onConnect,
  onDisconnect,
  stats,
  connectionStatus
}) => {
  const getStatusBadge = () => {
    switch (connectionStatus) {
      case 'connecting':
        return (
          <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30 animate-pulse">
            <Loader2 className="h-3 w-3 mr-1 animate-spin" />
            Connecting...
          </Badge>
        );
      case 'connected':
        return (
          <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
            <Wifi className="h-3 w-3 mr-1" />
            Connected
          </Badge>
        );
      case 'error':
        return (
          <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
            <WifiOff className="h-3 w-3 mr-1" />
            Connection Error
          </Badge>
        );
      default:
        return (
          <Badge className="bg-slate-500/20 text-slate-400 border-slate-500/30">
            <WifiOff className="h-3 w-3 mr-1" />
            Disconnected
          </Badge>
        );
    }
  };

  const getConnectionIcon = () => {
    switch (connectionStatus) {
      case 'connecting':
        return <Loader2 className="h-5 w-5 animate-spin" />;
      case 'connected':
        return <Zap className="h-5 w-5" />;
      case 'error':
        return <ZapOff className="h-5 w-5" />;
      default:
        return <ZapOff className="h-5 w-5" />;
    }
  };

  return (
    <Card className="bg-black/20 backdrop-blur-sm border-white/10 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-white text-sm">
            {getConnectionIcon()}
            Network Control
          </CardTitle>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Connection Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <Button
            onClick={onConnect}
            disabled={isConnected || connectionStatus === 'connecting'}
            className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-500 hover:to-green-400 text-white border-0 shadow-lg hover:shadow-green-500/25 transition-all duration-300"
            size="sm"
          >
            <Zap className="h-4 w-4 mr-1" />
            Connect
          </Button>
          <Button
            onClick={onDisconnect}
            disabled={!isConnected}
            variant="outline"
            className="bg-red-600/10 hover:bg-red-600/20 text-red-400 border-red-600/30 hover:border-red-500/50 transition-all duration-300"
            size="sm"
          >
            <ZapOff className="h-4 w-4 mr-1" />
            Disconnect
          </Button>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gradient-to-br from-blue-600/10 to-blue-800/10 border border-blue-500/20 rounded-lg p-3 text-center hover:from-blue-600/20 hover:to-blue-800/20 transition-all duration-300">
            <div className="text-xl font-bold text-blue-400 mb-1">
              {stats.totalStrikes.toLocaleString()}
            </div>
            <div className="text-xs text-slate-400 flex items-center justify-center gap-1">
              <Globe className="h-3 w-3" />
              Total Strikes
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-yellow-600/10 to-orange-800/10 border border-yellow-500/20 rounded-lg p-3 text-center hover:from-yellow-600/20 hover:to-orange-800/20 transition-all duration-300">
            <div className="text-xl font-bold text-yellow-400 mb-1">
              {stats.strikeRate}
            </div>
            <div className="text-xs text-slate-400 flex items-center justify-center gap-1">
              <Activity className="h-3 w-3" />
              Per Minute
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-purple-600/10 to-purple-800/10 border border-purple-500/20 rounded-lg p-3 text-center hover:from-purple-600/20 hover:to-purple-800/20 transition-all duration-300">
            <div className="text-xl font-bold text-purple-400 mb-1">
              {stats.filteredStrikes.toLocaleString()}
            </div>
            <div className="text-xs text-slate-400 flex items-center justify-center gap-1">
              <Target className="h-3 w-3" />
              In View
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-green-600/10 to-green-800/10 border border-green-500/20 rounded-lg p-3 text-center hover:from-green-600/20 hover:to-green-800/20 transition-all duration-300">
            <div className="text-xl font-bold text-green-400 mb-1 font-mono">
              {stats.uptime}
            </div>
            <div className="text-xs text-slate-400 flex items-center justify-center gap-1">
              <Clock className="h-3 w-3" />
              Uptime
            </div>
          </div>
        </div>

        {/* Connection Status Details */}
        {isConnected && (
          <div className="bg-black/20 rounded-lg p-3 border border-white/10">
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              <span>Real-time monitoring active</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Receiving data from global sensor network
            </div>
          </div>
        )}

        {connectionStatus === 'error' && (
          <div className="bg-red-600/10 border border-red-500/20 rounded-lg p-3">
            <div className="flex items-center gap-2 text-xs text-red-400">
              <div className="w-2 h-2 bg-red-400 rounded-full"></div>
              <span>Connection failed</span>
            </div>
            <div className="text-xs text-red-300/70 mt-1">
              Check network connection and try again
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ControlPanel;