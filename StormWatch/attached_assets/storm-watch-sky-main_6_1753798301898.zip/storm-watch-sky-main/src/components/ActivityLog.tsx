import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileText, Zap, AlertCircle, CheckCircle, Info } from 'lucide-react';

interface LogEntry {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'strike';
  timestamp: number;
}

interface ActivityLogProps {
  entries: LogEntry[];
}

const ActivityLog: React.FC<ActivityLogProps> = ({ entries }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [entries]);

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'strike':
        return <Zap className="h-3 w-3 text-lightning-secondary" />;
      case 'success':
        return <CheckCircle className="h-3 w-3 text-lightning-success" />;
      case 'warning':
        return <AlertCircle className="h-3 w-3 text-lightning-warning" />;
      case 'error':
        return <AlertCircle className="h-3 w-3 text-destructive" />;
      default:
        return <Info className="h-3 w-3 text-primary" />;
    }
  };

  const getLogColorClass = (type: string) => {
    switch (type) {
      case 'strike':
        return 'border-l-lightning-secondary bg-lightning-secondary/5';
      case 'success':
        return 'border-l-lightning-success bg-lightning-success/5';
      case 'warning':
        return 'border-l-lightning-warning bg-lightning-warning/5';
      case 'error':
        return 'border-l-destructive bg-destructive/5';
      default:
        return 'border-l-primary bg-primary/5';
    }
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50 flex flex-col">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-primary">
          <FileText className="h-5 w-5" />
          Activity Log
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 p-0">
        <ScrollArea className="h-64 px-6 pb-6">
          <div ref={scrollRef} className="space-y-2">
            {entries.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                No activity logged yet...
              </div>
            ) : (
              entries.map((entry) => (
                <div
                  key={entry.id}
                  className={`
                    flex items-start gap-3 p-3 rounded-md border-l-2 transition-all
                    ${getLogColorClass(entry.type)}
                  `}
                >
                  <div className="mt-1">
                    {getLogIcon(entry.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground font-mono leading-relaxed">
                      {entry.message}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {new Date(entry.timestamp).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default ActivityLog;