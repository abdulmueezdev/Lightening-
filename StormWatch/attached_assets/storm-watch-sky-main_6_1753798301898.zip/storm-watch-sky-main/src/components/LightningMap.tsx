
import React, { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, MapPin, Navigation, Zap, Clock, Globe, Target } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface LightningStrike {
  id: string;
  latitude: number;
  longitude: number;
  intensity: number;
  timestamp: number;
  city?: string;
  country?: string;
  region?: string;
}

interface LightningMapProps {
  strikes: LightningStrike[];
  apiKey?: string;
}

const LightningMap: React.FC<LightningMapProps> = ({ strikes, apiKey = 'pk.eyJ1IjoiYWJkdWxtdWVlejAwNyIsImEiOiJjbWRsN2Rrd2sxZGtyMm1yYjJ0MWJoNHB0In0.b_2Ce3x9eNL3n0x4gvn6iA' }) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const [mapboxToken, setMapboxToken] = useState(apiKey);
  const [showTokenInput, setShowTokenInput] = useState(false);
  const [city, setCity] = useState('');
  const [country, setCountry] = useState('');
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const currentMarkers = useRef<mapboxgl.Marker[]>([]);

  useEffect(() => {
    if (!mapContainer.current || !mapboxToken) return;

    // Initialize map
    mapboxgl.accessToken = mapboxToken;
    
    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/dark-v11',
        projection: 'globe' as any,
        zoom: 2.5,
        center: [0, 20],
        pitch: 0,
        antialias: true
      });

      // Add navigation controls
      map.current.addControl(
        new mapboxgl.NavigationControl({
          visualizePitch: true,
        }),
        'top-right'
      );

      // Add fullscreen control
      map.current.addControl(new mapboxgl.FullscreenControl(), 'top-right');

      // Add atmosphere and fog effects
      map.current.on('style.load', () => {
        map.current?.setFog({
          color: 'rgb(15, 15, 42)',
          'high-color': 'rgb(26, 26, 62)',
          'horizon-blend': 0.2,
          'space-color': 'rgb(5, 5, 25)',
          'star-intensity': 0.8
        });

        // Add a subtle glow effect to the globe
        map.current?.setPaintProperty('background', 'background-color', 'rgb(5, 5, 25)');
      });

      // Get user's location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const coords: [number, number] = [position.coords.longitude, position.coords.latitude];
            setUserLocation(coords);
            
            // Add user location marker
            const userEl = document.createElement('div');
            userEl.innerHTML = `
              <div style="
                width: 16px;
                height: 16px;
                background: #3b82f6;
                border: 3px solid white;
                border-radius: 50%;
                box-shadow: 0 0 15px rgba(59, 130, 246, 0.8);
                position: relative;
              ">
                <div style="
                  position: absolute;
                  top: -8px;
                  left: -8px;
                  width: 32px;
                  height: 32px;
                  border: 2px solid #3b82f6;
                  border-radius: 50%;
                  opacity: 0.3;
                  animation: pulse 2s infinite;
                "></div>
              </div>
            `;

            new mapboxgl.Marker({ element: userEl })
              .setLngLat(coords)
              .setPopup(
                new mapboxgl.Popup({ offset: 25, closeButton: false }).setHTML(`
                  <div class="user-location-popup">
                    <div class="popup-header">
                      <Navigation size="16" />
                      <span>Your Location</span>
                    </div>
                    <div class="popup-coords">${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}</div>
                  </div>
                `)
              )
              .addTo(map.current!);
          },
          (error) => console.log('Geolocation error:', error),
          { enableHighAccuracy: true, timeout: 10000 }
        );
      }

      // Cleanup
      return () => {
        map.current?.remove();
      };
    } catch (error) {
      console.error('Failed to initialize map:', error);
      setShowTokenInput(true);
    }
  }, [mapboxToken]);

  // Update strikes on map
  useEffect(() => {
    if (!map.current || !strikes.length) return;

    // Clear existing markers
    currentMarkers.current.forEach(marker => marker.remove());
    currentMarkers.current = [];

    // Add new strike markers
    strikes.forEach(strike => {
      const intensity = Math.min(Math.max(strike.intensity, 1), 10);
      const size = 20 + (intensity * 2);
      const opacity = Math.max(0.6, 1 - (Date.now() - strike.timestamp) / 180000); // Fade over 3 minutes

      // Create lightning strike element with improved design
      const el = document.createElement('div');
      el.className = 'lightning-marker';
      el.innerHTML = `
        <div class="lightning-strike-marker" style="
          width: ${size}px;
          height: ${size}px;
          background: radial-gradient(circle, ${getIntensityColor(intensity, 0.9)} 0%, ${getIntensityColor(intensity, 0.3)} 50%, transparent 100%);
          border: 2px solid ${getIntensityColor(intensity, 1)};
          border-radius: 50%;
          box-shadow: 
            0 0 ${size}px ${getIntensityColor(intensity, 0.6)},
            inset 0 0 ${size/4}px ${getIntensityColor(intensity, 0.8)};
          opacity: ${opacity};
          animation: lightning-pulse 1.5s ease-in-out infinite;
          cursor: pointer;
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
        ">
          <div style="
            color: white;
            font-size: ${Math.max(10, size/3)}px;
            text-shadow: 0 0 4px rgba(0,0,0,0.8);
            font-weight: bold;
          ">⚡</div>
        </div>
      `;

      // Format date and time with better formatting
      const strikeDate = new Date(strike.timestamp);
      const formattedDate = strikeDate.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });
      
      const formattedTime = strikeDate.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        timeZoneName: 'short'
      });

      // Create comprehensive location string
      let locationString = 'Unknown Location';
      let locationDetails = '';
      
      if (strike.city && strike.country) {
        locationString = `${strike.city}, ${strike.country}`;
        if (strike.region && strike.region !== strike.city) {
          locationDetails = strike.region;
        }
      } else if (strike.country) {
        locationString = strike.country;
      } else {
        locationString = 'Ocean/Remote Area';
      }

      // Calculate time ago
      const timeAgo = getTimeAgo(strike.timestamp);

      const marker = new mapboxgl.Marker({ 
        element: el,
        anchor: 'center' // This ensures the marker is centered on the coordinates
      })
        .setLngLat([strike.longitude, strike.latitude])
        .setPopup(
          new mapboxgl.Popup({ 
            offset: 25, 
            closeButton: true,
            closeOnClick: false,
            className: 'lightning-popup'
          }).setHTML(`
            <div class="lightning-popup-content">
              <div class="popup-header">
                <div class="lightning-icon">⚡</div>
                <div class="header-text">
                  <h3>Lightning Strike Detected</h3>
                  <span class="strike-id">#${strike.id.slice(-8)}</span>
                </div>
              </div>
              
              <div class="popup-body">
                <div class="info-row">
                  <div class="info-icon"><Globe size="16" /></div>
                  <div class="info-content">
                    <div class="info-label">Location</div>
                    <div class="info-value primary">${locationString}</div>
                    ${locationDetails ? `<div class="info-subvalue">${locationDetails}</div>` : ''}
                  </div>
                </div>
                
                <div class="info-row">
                  <div class="info-icon"><MapPin size="16" /></div>
                  <div class="info-content">
                    <div class="info-label">Coordinates</div>
                    <div class="info-value">${strike.latitude.toFixed(6)}°, ${strike.longitude.toFixed(6)}°</div>
                  </div>
                </div>
                
                <div class="info-row">
                  <div class="info-icon"><Clock size="16" /></div>
                  <div class="info-content">
                    <div class="info-label">Date & Time</div>
                    <div class="info-value">${formattedDate}</div>
                    <div class="info-subvalue">${formattedTime}</div>
                    <div class="time-ago">${timeAgo}</div>
                  </div>
                </div>
                
                <div class="info-row">
                  <div class="info-icon"><Zap size="16" /></div>
                  <div class="info-content">
                    <div class="info-label">Intensity</div>
                    <div class="intensity-display">
                      <span class="intensity-value" style="color: ${getIntensityColor(intensity, 1)}">${intensity}/10</span>
                      <div class="intensity-bar">
                        <div class="intensity-fill" style="
                          width: ${intensity * 10}%; 
                          background: linear-gradient(90deg, ${getIntensityColor(intensity, 1)}, ${getIntensityColor(intensity, 0.7)});
                        "></div>
                      </div>
                      <span class="intensity-label">${getIntensityLabel(intensity)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          `)
        )
        .addTo(map.current);

      currentMarkers.current.push(marker);
    });
  }, [strikes]);

  const getIntensityColor = (intensity: number, alpha: number = 1) => {
    const colors = [
      `rgba(34, 197, 94, ${alpha})`,   // Green - Low
      `rgba(101, 163, 13, ${alpha})`,  // Lime
      `rgba(234, 179, 8, ${alpha})`,   // Yellow
      `rgba(249, 115, 22, ${alpha})`,  // Orange
      `rgba(239, 68, 68, ${alpha})`,   // Red
      `rgba(220, 38, 127, ${alpha})`,  // Pink
      `rgba(168, 85, 247, ${alpha})`,  // Purple
      `rgba(147, 51, 234, ${alpha})`,  // Violet
      `rgba(99, 102, 241, ${alpha})`,  // Indigo
      `rgba(79, 70, 229, ${alpha})`    // Blue - Extreme
    ];
    return colors[Math.min(intensity - 1, 9)];
  };

  const getIntensityLabel = (intensity: number) => {
    const labels = ['Weak', 'Light', 'Moderate', 'Strong', 'Very Strong', 'Severe', 'Extreme', 'Catastrophic', 'Devastating', 'Apocalyptic'];
    return labels[Math.min(intensity - 1, 9)];
  };

  const getTimeAgo = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    
    if (seconds < 60) return `${seconds}s ago`;
    if (minutes < 60) return `${minutes}m ago`;
    return `${hours}h ago`;
  };

  const searchLocation = async () => {
    if (!city.trim()) return;

    try {
      const query = country ? `${city}, ${country}` : city;
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=1`
      );
      const data = await response.json();

      if (data.length > 0) {
        const location = data[0];
        const coordinates: [number, number] = [parseFloat(location.lon), parseFloat(location.lat)];
        
        map.current?.flyTo({
          center: coordinates,
          zoom: 10,
          duration: 2000,
          essential: true
        });

        // Add search result marker
        const searchEl = document.createElement('div');
        searchEl.innerHTML = `
          <div style="
            width: 24px;
            height: 24px;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            border: 3px solid white;
            border-radius: 50%;
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
            font-weight: bold;
            animation: search-pulse 2s ease-in-out infinite;
          ">📍</div>
        `;

        const searchMarker = new mapboxgl.Marker({ element: searchEl })
          .setLngLat(coordinates)
          .setPopup(
            new mapboxgl.Popup({ offset: 25, className: 'search-popup' }).setHTML(`
              <div class="search-popup-content">
                <div class="popup-header">
                  <Search size="16" />
                  <span>Search Result</span>
                </div>
                <div class="location-name">${location.display_name}</div>
                <div class="coordinates">${coordinates[1].toFixed(4)}, ${coordinates[0].toFixed(4)}</div>
              </div>
            `)
          )
          .addTo(map.current!);

        // Remove search marker after 10 seconds
        setTimeout(() => {
          searchMarker.remove();
        }, 10000);
      }
    } catch (error) {
      console.error('Search failed:', error);
    }
  };

  const flyToUserLocation = () => {
    if (userLocation && map.current) {
      map.current.flyTo({
        center: userLocation,
        zoom: 8,
        duration: 2000,
        essential: true
      });
    }
  };

  if (showTokenInput) {
    return (
      <Card className="h-full flex items-center justify-center p-8">
        <div className="text-center space-y-4 max-w-md">
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">Enter Mapbox Token</h3>
            <p className="text-sm text-muted-foreground">
              Get your free token from{' '}
              <a href="https://mapbox.com/" target="_blank" rel="noopener noreferrer" className="text-primary underline">
                mapbox.com
              </a>
            </p>
          </div>
          <div className="space-y-3">
            <Input
              type="password"
              placeholder="pk.eyJ1..."
              value={mapboxToken}
              onChange={(e) => setMapboxToken(e.target.value)}
              className="w-full"
            />
            <Button 
              onClick={() => mapboxToken && setShowTokenInput(false)}
              disabled={!mapboxToken.trim()}
              className="w-full"
            >
              Initialize Map
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div className="relative h-full rounded-xl overflow-hidden bg-gradient-to-br from-slate-900 to-slate-800">
      {/* Enhanced Search Controls */}
      <div className="absolute top-4 left-4 z-10 flex flex-col sm:flex-row gap-2">
        <div className="flex gap-2">
          <Input
            placeholder="Enter city"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-36 bg-black/20 backdrop-blur-md border-white/20 text-white placeholder:text-white/60"
            onKeyPress={(e) => e.key === 'Enter' && searchLocation()}
          />
          <Input
            placeholder="Country"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            className="w-32 bg-black/20 backdrop-blur-md border-white/20 text-white placeholder:text-white/60"
            onKeyPress={(e) => e.key === 'Enter' && searchLocation()}
          />
          <Button 
            size="sm" 
            onClick={searchLocation}
            className="bg-blue-600/80 backdrop-blur-md hover:bg-blue-600 border-0"
          >
            <Search className="h-4 w-4" />
          </Button>
        </div>
        {userLocation && (
          <Button 
            size="sm" 
            onClick={flyToUserLocation}
            className="bg-green-600/80 backdrop-blur-md hover:bg-green-600 border-0"
          >
            <Navigation className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Strike Counter */}
      <div className="absolute top-4 right-4 z-10 bg-black/20 backdrop-blur-md rounded-lg px-3 py-2 text-white text-sm">
        <div className="flex items-center gap-2">
          <Target className="h-4 w-4 text-yellow-400" />
          <span>{strikes.length} Active Strikes</span>
        </div>
      </div>

      {/* Map Container */}
      <div ref={mapContainer} className="w-full h-full" />

      {/* Custom CSS for animations and styles */}
      <style>{`
        @keyframes lightning-pulse {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.2); }
        }
        
        @keyframes pulse {
          0%, 100% { transform: scale(1); opacity: 0.3; }
          50% { transform: scale(1.2); opacity: 0.1; }
        }
        
        @keyframes search-pulse {
          0%, 100% { transform: scale(1); box-shadow: 0 0 20px rgba(59, 130, 246, 0.8); }
          50% { transform: scale(1.1); box-shadow: 0 0 30px rgba(59, 130, 246, 1); }
        }

        .lightning-popup .mapboxgl-popup-content {
          background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
          border: 1px solid #334155;
          border-radius: 12px;
          padding: 0;
          box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 10px 10px -5px rgba(0, 0, 0, 0.2);
          max-width: 350px;
        }

        .lightning-popup-content {
          color: white;
          font-family: system-ui, -apple-system, sans-serif;
        }

        .popup-header {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 16px 16px 12px 16px;
          border-bottom: 1px solid #334155;
          background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
          border-radius: 12px 12px 0 0;
        }

        .lightning-icon {
          font-size: 24px;
          background: linear-gradient(135deg, #fbbf24, #f59e0b);
          border-radius: 50%;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          box-shadow: 0 0 15px rgba(251, 191, 36, 0.5);
        }

        .header-text h3 {
          margin: 0;
          font-size: 16px;
          font-weight: 600;
          color: #e2e8f0;
        }

        .strike-id {
          font-size: 12px;
          color: #94a3b8;
          font-family: monospace;
        }

        .popup-body {
          padding: 16px;
        }

        .info-row {
          display: flex;
          align-items: flex-start;
          gap: 12px;
          margin-bottom: 16px;
        }

        .info-row:last-child {
          margin-bottom: 0;
        }

        .info-icon {
          color: #60a5fa;
          margin-top: 2px;
          flex-shrink: 0;
        }

        .info-content {
          flex: 1;
        }

        .info-label {
          font-size: 12px;
          color: #94a3b8;
          margin-bottom: 4px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .info-value {
          font-size: 14px;
          color: #e2e8f0;
          font-weight: 500;
          line-height: 1.4;
        }

        .info-value.primary {
          color: #60a5fa;
          font-weight: 600;
        }

        .info-subvalue {
          font-size: 12px;
          color: #94a3b8;
          margin-top: 2px;
        }

        .time-ago {
          font-size: 11px;
          color: #fbbf24;
          margin-top: 4px;
          font-weight: 500;
        }

        .intensity-display {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .intensity-value {
          font-size: 16px;
          font-weight: 700;
        }

        .intensity-bar {
          width: 100%;
          height: 6px;
          background: #334155;
          border-radius: 3px;
          overflow: hidden;
        }

        .intensity-fill {
          height: 100%;
          border-radius: 3px;
          transition: width 0.3s ease;
        }

        .intensity-label {
          font-size: 11px;
          color: #94a3b8;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }

        .user-location-popup,
        .search-popup-content {
          background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
          border: 1px solid #475569;
          border-radius: 8px;
          padding: 12px;
          color: white;
          font-family: system-ui, -apple-system, sans-serif;
        }

        .user-location-popup .popup-header,
        .search-popup-content .popup-header {
          display: flex;
          align-items: center;
          gap: 8px;
          color: #60a5fa;
          font-weight: 500;
          margin-bottom: 8px;
        }

        .popup-coords,
        .coordinates {
          font-family: monospace;
          font-size: 12px;
          color: #94a3b8;
        }

        .location-name {
          font-size: 14px;
          color: #e2e8f0;
          margin-bottom: 4px;
          font-weight: 500;
        }
      `}</style>
    </div>
  );
};

export default LightningMap;
