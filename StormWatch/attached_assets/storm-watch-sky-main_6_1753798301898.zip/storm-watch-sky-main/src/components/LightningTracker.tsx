import React, { useState, useEffect, useCallback } from 'react';
import { lightningService, LightningStrike, LogEntry } from '@/services/lightningService';
import LightningMap from './LightningMap';
import ControlPanel from './ControlPanel';
import ActivityChart from './ActivityChart';
import ActivityLog from './ActivityLog';
import { Zap, Cloud, Sun, CloudRain, Wind, Thermometer, Eye, Droplets } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const LightningTracker: React.FC = () => {
  const [strikes, setStrikes] = useState<LightningStrike[]>([]);
  const [logEntries, setLogEntries] = useState<LogEntry[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  const [connectionStartTime, setConnectionStartTime] = useState<number | null>(null);
  const [uptime, setUptime] = useState('00:00');
  const [activityData, setActivityData] = useState<Array<{ time: string; strikes: number }>>([]);

  // Weather simulation data
  const [weatherData, setWeatherData] = useState({
    temperature: 22,
    humidity: 65,
    windSpeed: 12,
    visibility: 10,
    pressure: 1013,
    uvIndex: 6,
    cloudCover: 45,
    dewPoint: 16
  });

  // Statistics
  const [stats, setStats] = useState({
    totalStrikes: 0,
    strikeRate: 0,
    filteredStrikes: 0,
    uptime: '00:00',
  });

  // Handle new lightning strikes
  const handleLightningStrike = useCallback((strike: LightningStrike) => {
    setStrikes(prev => {
      const newStrikes = [strike, ...prev];
      // Keep only last 100 strikes for performance
      return newStrikes.slice(0, 100);
    });

    setStats(prev => ({
      ...prev,
      totalStrikes: prev.totalStrikes + 1,
      filteredStrikes: prev.filteredStrikes + 1,
    }));

    // Simulate weather changes based on lightning activity
    setWeatherData(prev => ({
      ...prev,
      temperature: Math.max(15, Math.min(35, prev.temperature + (Math.random() - 0.5) * 2)),
      humidity: Math.max(30, Math.min(95, prev.humidity + (Math.random() - 0.5) * 10)),
      windSpeed: Math.max(0, Math.min(50, prev.windSpeed + (Math.random() - 0.5) * 5)),
      pressure: Math.max(980, Math.min(1040, prev.pressure + (Math.random() - 0.5) * 5)),
      cloudCover: Math.max(0, Math.min(100, prev.cloudCover + (Math.random() - 0.5) * 15))
    }));
  }, []);

  // Handle log entries
  const handleLogEntry = useCallback((entry: LogEntry) => {
    setLogEntries(prev => {
      const newEntries = [entry, ...prev];
      return newEntries.slice(0, 50);
    });
  }, []);

  // Connect to lightning service
  const handleConnect = useCallback(async () => {
    setConnectionStatus('connecting');
    setLogEntries(prev => [...prev, {
      id: Date.now().toString(),
      message: 'Initializing global weather monitoring systems...',
      type: 'info',
      timestamp: Date.now(),
    }]);

    try {
      await lightningService.connect();
      setIsConnected(true);
      setConnectionStatus('connected');
      setConnectionStartTime(Date.now());
      
      const uptimeInterval = setInterval(() => {
        if (connectionStartTime) {
          const elapsed = Date.now() - connectionStartTime;
          const minutes = Math.floor(elapsed / 60000);
          const seconds = Math.floor((elapsed % 60000) / 1000);
          const uptimeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
          setUptime(uptimeString);
          setStats(prev => ({ ...prev, uptime: uptimeString }));
        }
      }, 1000);

      const rateInterval = setInterval(() => {
        if (connectionStartTime) {
          const elapsed = (Date.now() - connectionStartTime) / 60000;
          const rate = elapsed > 0 ? Math.round(stats.totalStrikes / elapsed) : 0;
          setStats(prev => ({ ...prev, strikeRate: rate }));
          
          const now = new Date();
          const timeLabel = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          setActivityData(prev => {
            const newData = [...prev, { time: timeLabel, strikes: rate }];
            return newData.slice(-20);
          });
        }
      }, 60000);

      return () => {
        clearInterval(uptimeInterval);
        clearInterval(rateInterval);
      };
    } catch (error) {
      setConnectionStatus('error');
      setLogEntries(prev => [...prev, {
        id: Date.now().toString(),
        message: 'Failed to connect to weather monitoring network',
        type: 'error',
        timestamp: Date.now(),
      }]);
    }
  }, [connectionStartTime, stats.totalStrikes]);

  // Disconnect from lightning service
  const handleDisconnect = useCallback(() => {
    lightningService.disconnect();
    setIsConnected(false);
    setConnectionStatus('disconnected');
    setConnectionStartTime(null);
    setUptime('00:00');
    setStats(prev => ({ ...prev, uptime: '00:00' }));
  }, []);

  // Set up event listeners
  useEffect(() => {
    lightningService.on('lightning_strike', handleLightningStrike);
    lightningService.on('log', handleLogEntry);

    return () => {
      lightningService.off('lightning_strike', handleLightningStrike);
      lightningService.off('log', handleLogEntry);
    };
  }, [handleLightningStrike, handleLogEntry]);

  // Simulate weather updates
  useEffect(() => {
    const weatherInterval = setInterval(() => {
      setWeatherData(prev => ({
        ...prev,
        temperature: Math.max(15, Math.min(35, prev.temperature + (Math.random() - 0.5) * 0.5)),
        humidity: Math.max(30, Math.min(95, prev.humidity + (Math.random() - 0.5) * 2)),
        windSpeed: Math.max(0, Math.min(50, prev.windSpeed + (Math.random() - 0.5) * 1)),
        pressure: Math.max(980, Math.min(1040, prev.pressure + (Math.random() - 0.5) * 0.5)),
        uvIndex: Math.max(0, Math.min(11, prev.uvIndex + (Math.random() - 0.5) * 0.5)),
        visibility: Math.max(1, Math.min(20, prev.visibility + (Math.random() - 0.5) * 0.5)),
        dewPoint: Math.max(0, Math.min(25, prev.dewPoint + (Math.random() - 0.5) * 0.5))
      }));
    }, 30000); // Update every 30 seconds

    return () => clearInterval(weatherInterval);
  }, []);

  // Simulate connection issues
  useEffect(() => {
    if (isConnected) {
      const issueInterval = setInterval(() => {
        if (Math.random() < 0.2) {
          lightningService.simulateConnectionIssues();
        }
      }, 45000);

      return () => clearInterval(issueInterval);
    }
  }, [isConnected]);

  const getCurrentTime = () => {
    return new Date().toLocaleString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZoneName: 'short'
    });
  };

  const getWeatherIcon = () => {
    if (weatherData.cloudCover > 80) return <CloudRain className="h-6 w-6 text-blue-400" />;
    if (weatherData.cloudCover > 50) return <Cloud className="h-6 w-6 text-gray-400" />;
    return <Sun className="h-6 w-6 text-yellow-400" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-900">
      {/* Enhanced Header */}
      <header className="bg-black/20 backdrop-blur-xl border-b border-white/10 sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-gradient-to-br from-yellow-400 to-orange-500 shadow-lg shadow-yellow-500/25">
                <Zap className="h-8 w-8 text-black" />
              </div>
              <div className="text-center lg:text-left">
                <h1 className="text-2xl sm:text-3xl font-bold bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
                  Global Weather & Lightning Tracker
                </h1>
                <p className="text-sm sm:text-base text-slate-300 mt-1">
                  Real-time atmospheric monitoring and lightning detection worldwide
                </p>
              </div>
            </div>
            
            {/* Real-time clock and weather summary */}
            <div className="flex flex-col sm:flex-row items-center gap-4 text-sm">
              <div className="text-center sm:text-right">
                <div className="text-white font-mono text-lg">
                  {getCurrentTime().split(',')[1]?.trim().split(' ')[0]} {getCurrentTime().split(' ').slice(-1)[0]}
                </div>
                <div className="text-slate-400">
                  {getCurrentTime().split(',')[0]}
                </div>
              </div>
              <div className="flex items-center gap-2 bg-black/20 rounded-lg px-3 py-2">
                {getWeatherIcon()}
                <span className="text-white font-semibold">{Math.round(weatherData.temperature)}°C</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 sm:px-6 py-6">
        {/* Weather Overview Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 mb-6">
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Thermometer className="h-5 w-5 text-red-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.temperature)}°C</div>
              <div className="text-xs text-slate-400">Temperature</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Droplets className="h-5 w-5 text-blue-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.humidity)}%</div>
              <div className="text-xs text-slate-400">Humidity</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Wind className="h-5 w-5 text-green-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.windSpeed)}</div>
              <div className="text-xs text-slate-400">Wind km/h</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Eye className="h-5 w-5 text-purple-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.visibility)}</div>
              <div className="text-xs text-slate-400">Visibility km</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <div className="text-yellow-400 mx-auto mb-1 text-lg">📊</div>
              <div className="text-lg font-bold text-white">{Math.round(weatherData.pressure)}</div>
              <div className="text-xs text-slate-400">Pressure hPa</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Sun className="h-5 w-5 text-orange-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.uvIndex)}</div>
              <div className="text-xs text-slate-400">UV Index</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <Cloud className="h-5 w-5 text-gray-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">{Math.round(weatherData.cloudCover)}%</div>
              <div className="text-xs text-slate-400">Cloud Cover</div>
            </CardContent>
          </Card>
          
          <Card className="bg-black/20 backdrop-blur-sm border-white/10 hover:bg-black/30 transition-all duration-300">
            <CardContent className="p-3 text-center">
              <div className="text-cyan-400 mx-auto mb-1 text-lg">💧</div>
              <div className="text-lg font-bold text-white">{Math.round(weatherData.dewPoint)}°C</div>
              <div className="text-xs text-slate-400">Dew Point</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-4 gap-6 h-[calc(100vh-280px)] min-h-[600px]">
          {/* Map Section - Takes up 3 columns on xl screens */}
          <div className="xl:col-span-3">
            <Card className="h-full bg-black/20 backdrop-blur-sm border-white/10 overflow-hidden shadow-2xl shadow-blue-500/10">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-white">
                  <Zap className="h-5 w-5 text-yellow-400" />
                  Live Lightning Activity Map
                  <div className="ml-auto text-sm font-normal text-slate-400">
                    {strikes.length} active strikes
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 h-[calc(100%-4rem)]">
                <LightningMap strikes={strikes} />
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Takes up 1 column */}
          <div className="space-y-4 h-full overflow-y-auto">
            {/* Control Panel */}
            <ControlPanel
              isConnected={isConnected}
              onConnect={handleConnect}
              onDisconnect={handleDisconnect}
              stats={stats}
              connectionStatus={connectionStatus}
            />

            {/* Activity Chart */}
            <Card className="bg-black/20 backdrop-blur-sm border-white/10">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white flex items-center gap-2">
                  <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                  Strike Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3">
                <ActivityChart data={activityData} />
              </CardContent>
            </Card>

            {/* Activity Log */}
            <Card className="bg-black/20 backdrop-blur-sm border-white/10 flex-1">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm text-white flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  System Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="p-3 h-[calc(100%-4rem)]">
                <ActivityLog entries={logEntries} />
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-black/20 backdrop-blur-xl border-t border-white/10 mt-8">
        <div className="container mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-slate-400">
            <div className="flex items-center gap-4">
              <span>© 2024 Global Weather Tracker</span>
              <div className="flex items-center gap-1">
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`}></div>
                <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
              </div>
            </div>
            <div className="text-xs text-slate-500">
              Powered by advanced meteorological sensors and satellite networks
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LightningTracker;
