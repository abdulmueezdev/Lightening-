import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingUp } from 'lucide-react';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface ActivityChartProps {
  data: Array<{
    time: string;
    strikes: number;
  }>;
}

const ActivityChart: React.FC<ActivityChartProps> = ({ data }) => {
  const chartData = {
    labels: data.map(d => d.time),
    datasets: [
      {
        label: 'Strikes per Minute',
        data: data.map(d => d.strikes),
        borderColor: 'hsl(196 100% 50%)',
        backgroundColor: 'hsl(196 100% 50% / 0.1)',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
        pointRadius: 3,
        pointBorderColor: 'hsl(196 100% 50%)',
        pointBackgroundColor: 'hsl(196 100% 50%)',
        pointHoverRadius: 5,
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
      tooltip: {
        backgroundColor: 'hsl(230 35% 10%)',
        titleColor: 'hsl(196 100% 50%)',
        bodyColor: 'white',
        borderColor: 'hsl(196 100% 50%)',
        borderWidth: 1,
      },
    },
    scales: {
      x: {
        grid: {
          color: 'hsl(230 35% 18%)',
        },
        ticks: {
          color: 'hsl(210 20% 65%)',
          maxTicksLimit: 6,
        },
      },
      y: {
        grid: {
          color: 'hsl(230 35% 18%)',
        },
        ticks: {
          color: 'hsl(210 20% 65%)',
        },
        beginAtZero: true,
      },
    },
    elements: {
      point: {
        hoverBackgroundColor: 'hsl(196 100% 50%)',
      },
    },
  };

  return (
    <Card className="bg-card/50 backdrop-blur-sm border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-primary">
          <TrendingUp className="h-5 w-5" />
          Activity Trend
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-48">
          <Line data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  );
};

export default ActivityChart;