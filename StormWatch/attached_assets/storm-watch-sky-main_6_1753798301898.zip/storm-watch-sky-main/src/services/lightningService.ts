
// Enhanced Lightning Service - Provides comprehensive global lightning data
// Now includes major cities worldwide and better location resolution

export interface LightningStrike {
  id: string;
  latitude: number;
  longitude: number;
  intensity: number; // 1-10 scale
  timestamp: number;
  city?: string;
  country?: string;
  region?: string;
}

export interface LogEntry {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'strike';
  timestamp: number;
}

export class LightningService {
  private eventTarget = new EventTarget();
  private isConnected = false;
  private intervalId: NodeJS.Timeout | null = null;
  private strikeCounter = 0;
  
  // Global lightning hotspots with major cities - areas with higher probability of strikes
  private hotspots = [
    // Americas
    { lat: 0, lng: -60, name: 'Amazon Basin', cities: ['Manaus', 'Belém', 'Santarém'], country: 'Brazil' },
    { lat: 30, lng: -95, name: 'Gulf Coast USA', cities: ['Houston', 'New Orleans', 'Tampa'], country: 'USA' },
    { lat: 35, lng: -80, name: 'Southeastern USA', cities: ['Atlanta', 'Charlotte', 'Nashville'], country: 'USA' },
    { lat: 25, lng: -80, name: 'Florida', cities: ['Miami', 'Orlando', 'Jacksonville'], country: 'USA' },
    { lat: 40, lng: -100, name: 'Great Plains', cities: ['Oklahoma City', 'Kansas City', 'Denver'], country: 'USA' },
    { lat: -15, lng: -50, name: 'Brazilian Highlands', cities: ['Brasília', 'Goiânia', 'Cuiabá'], country: 'Brazil' },
    { lat: -35, lng: -60, name: 'Pampas', cities: ['Buenos Aires', 'Montevideo', 'Rosario'], country: 'Argentina' },
    
    // Africa
    { lat: 5, lng: 30, name: 'Central Africa', cities: ['Kinshasa', 'Bangui', 'Kampala'], country: 'Congo' },
    { lat: 10, lng: 20, name: 'Sahel', cities: ['N\'Djamena', 'Khartoum', 'Niamey'], country: 'Chad' },
    { lat: -20, lng: 30, name: 'Southern Africa', cities: ['Harare', 'Lusaka', 'Gaborone'], country: 'Zimbabwe' },
    { lat: 0, lng: 35, name: 'East Africa', cities: ['Nairobi', 'Dar es Salaam', 'Addis Ababa'], country: 'Kenya' },
    { lat: 15, lng: 0, name: 'West Africa', cities: ['Lagos', 'Abidjan', 'Accra'], country: 'Nigeria' },
    
    // Asia
    { lat: 20, lng: 90, name: 'Bay of Bengal', cities: ['Dhaka', 'Kolkata', 'Chittagong'], country: 'Bangladesh' },
    { lat: 10, lng: 105, name: 'Southeast Asia', cities: ['Bangkok', 'Ho Chi Minh City', 'Kuala Lumpur'], country: 'Thailand' },
    { lat: 30, lng: 110, name: 'South China', cities: ['Guangzhou', 'Shenzhen', 'Hong Kong'], country: 'China' },
    { lat: 20, lng: 77, name: 'Indian Subcontinent', cities: ['Mumbai', 'Delhi', 'Bangalore'], country: 'India' },
    { lat: 35, lng: 130, name: 'Japan', cities: ['Tokyo', 'Osaka', 'Nagoya'], country: 'Japan' },
    { lat: 0, lng: 120, name: 'Indonesia', cities: ['Jakarta', 'Surabaya', 'Medan'], country: 'Indonesia' },
    
    // Europe
    { lat: 50, lng: 10, name: 'Central Europe', cities: ['Berlin', 'Prague', 'Vienna'], country: 'Germany' },
    { lat: 45, lng: 2, name: 'Western Europe', cities: ['Paris', 'Lyon', 'Marseille'], country: 'France' },
    { lat: 52, lng: -2, name: 'British Isles', cities: ['London', 'Manchester', 'Edinburgh'], country: 'UK' },
    { lat: 40, lng: -4, name: 'Iberian Peninsula', cities: ['Madrid', 'Barcelona', 'Lisbon'], country: 'Spain' },
    { lat: 60, lng: 25, name: 'Nordic Region', cities: ['Stockholm', 'Helsinki', 'Oslo'], country: 'Sweden' },
    
    // Oceania
    { lat: -25, lng: 135, name: 'Northern Australia', cities: ['Darwin', 'Alice Springs', 'Brisbane'], country: 'Australia' },
    { lat: -35, lng: 150, name: 'Eastern Australia', cities: ['Sydney', 'Melbourne', 'Canberra'], country: 'Australia' },
    { lat: -40, lng: 175, name: 'New Zealand', cities: ['Auckland', 'Wellington', 'Christchurch'], country: 'New Zealand' },
  ];

  connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (this.isConnected) {
        resolve();
        return;
      }

      // Simulate connection delay
      setTimeout(() => {
        this.isConnected = true;
        this.startDataGeneration();
        
        this.emit('connected', { message: 'Connected to global lightning network' });
        this.emit('log', {
          id: Date.now().toString(),
          message: 'Successfully connected to global lightning detection network - monitoring worldwide activity',
          type: 'success',
          timestamp: Date.now(),
        });
        
        resolve();
      }, 2000);
    });
  }

  disconnect(): void {
    this.isConnected = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    
    this.emit('disconnected', { message: 'Disconnected from lightning network' });
    this.emit('log', {
      id: Date.now().toString(),
      message: 'Disconnected from global lightning network',
      type: 'info',
      timestamp: Date.now(),
    });
  }

  private startDataGeneration(): void {
    // Generate lightning strikes at realistic intervals (every 0.3-2 seconds globally)
    this.intervalId = setInterval(async () => {
      if (!this.isConnected) return;

      // Generate 1-8 strikes per interval to simulate realistic global activity
      const numStrikes = Math.floor(Math.random() * 8) + 1;
      
      for (let i = 0; i < numStrikes; i++) {
        const strike = await this.generateRealisticStrike();
        this.emit('lightning_strike', strike);
        
        const locationInfo = this.formatLocationInfo(strike);
        const timeInfo = new Date(strike.timestamp).toLocaleTimeString('en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        });
          
        this.emit('log', {
          id: `${Date.now()}-${i}`,
          message: `⚡ Lightning detected: ${locationInfo} at ${timeInfo} (Intensity: ${strike.intensity}/10)`,
          type: 'strike',
          timestamp: Date.now(),
        });
      }
    }, Math.random() * 1700 + 300); // Random interval between 0.3-2 seconds
  }

  private formatLocationInfo(strike: LightningStrike): string {
    if (strike.city && strike.country) {
      return `${strike.city}, ${strike.country}${strike.region ? `, ${strike.region}` : ''}`;
    }
    return `${strike.latitude.toFixed(3)}°, ${strike.longitude.toFixed(3)}°`;
  }

  private async generateRealisticStrike(): Promise<LightningStrike> {
    this.strikeCounter++;
    
    // 70% chance to generate near a hotspot, 30% random
    const useHotspot = Math.random() < 0.7;
    let latitude: number;
    let longitude: number;
    let selectedHotspot: any = null;

    if (useHotspot) {
      selectedHotspot = this.hotspots[Math.floor(Math.random() * this.hotspots.length)];
      // Add variation around the hotspot (±8 degrees for more spread)
      latitude = selectedHotspot.lat + (Math.random() - 0.5) * 16;
      longitude = selectedHotspot.lng + (Math.random() - 0.5) * 16;
    } else {
      // Random location on Earth (avoiding extreme polar regions)
      latitude = (Math.random() - 0.5) * 140; // -70 to 70 degrees
      longitude = (Math.random() - 0.5) * 360; // -180 to 180 degrees
    }

    // Ensure coordinates are within valid ranges
    latitude = Math.max(-85, Math.min(85, latitude));
    longitude = Math.max(-180, Math.min(180, longitude));

    // Generate intensity with realistic distribution
    const intensityRand = Math.random();
    let intensity: number;
    if (intensityRand < 0.25) intensity = 1 + Math.floor(Math.random() * 3); // 1-3 (25%)
    else if (intensityRand < 0.5) intensity = 4 + Math.floor(Math.random() * 2); // 4-5 (25%)
    else if (intensityRand < 0.75) intensity = 6 + Math.floor(Math.random() * 2); // 6-7 (25%)
    else if (intensityRand < 0.9) intensity = 8 + Math.floor(Math.random() * 2); // 8-9 (15%)
    else intensity = 10; // 10 (10%)

    const strike: LightningStrike = {
      id: `strike-${this.strikeCounter}-${Date.now()}`,
      latitude,
      longitude,
      intensity,
      timestamp: Date.now(),
    };

    // Add location info - try to get city/country information
    await this.addLocationInfo(strike, selectedHotspot);
    
    return strike;
  }

  private async addLocationInfo(strike: LightningStrike, hotspot: any): Promise<void> {
    try {
      // If we used a hotspot, randomly assign a city from that hotspot
      if (hotspot && Math.random() < 0.6) {
        const city = hotspot.cities[Math.floor(Math.random() * hotspot.cities.length)];
        strike.city = city;
        strike.country = hotspot.country;
        strike.region = hotspot.name;
      } else {
        // Use reverse geocoding for more accurate location data
        const response = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${strike.latitude}&lon=${strike.longitude}&zoom=10&addressdetails=1`
        );
        
        if (response.ok) {
          const data = await response.json();
          
          if (data && data.address) {
            strike.city = data.address.city || 
                         data.address.town || 
                         data.address.village || 
                         data.address.municipality || 
                         data.address.county;
            strike.country = data.address.country;
            strike.region = data.address.state || 
                           data.address.region || 
                           data.address.province;
          }
        }
      }
    } catch (error) {
      // Silently fail for location lookup - coordinates will be shown instead
      console.log('Location lookup failed:', error);
    }
  }

  private emit(event: string, data: any): void {
    this.eventTarget.dispatchEvent(new CustomEvent(event, { detail: data }));
  }

  on(event: string, callback: (data: any) => void): void {
    this.eventTarget.addEventListener(event, (e: any) => callback(e.detail));
  }

  off(event: string, callback: (data: any) => void): void {
    this.eventTarget.removeEventListener(event, callback);
  }

  getConnectionStatus(): boolean {
    return this.isConnected;
  }

  // Simulate some connection issues occasionally
  simulateConnectionIssues(): void {
    if (!this.isConnected) return;

    const issues = [
      'Network latency detected - recalibrating sensors',
      'Reconnecting to satellite network...',
      'Data quality verification completed',
      'Global monitoring systems synchronized',
      'Lightning detection array optimized',
    ];

    const randomIssue = issues[Math.floor(Math.random() * issues.length)];
    this.emit('log', {
      id: Date.now().toString(),
      message: randomIssue,
      type: 'warning',
      timestamp: Date.now(),
    });
  }
}

export const lightningService = new LightningService();
