import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
// GIthub Copilot prompt.
// I’m building a weather-tracking website using React, Mapbox, and OpenWeatherMap. Please review and correct my code so that:

// The search bar properly fetches and displays:

// Temperature

// Humidity

// Wind Speed

// Weather Description

// City & Country

// Suggestions for city names appear while typing.

// The data comes from OpenWeatherMap (using VITE_OPENWEATHERMAP_API_KEY from .env).

// The map updates location and marker based on the searched city.

// The Mapbox error: "The layer 'background' does not exist" must be fixed by checking style compatibility.

// CORS errors from nominatim.openstreetmap.org (used for reverse geocoding) should be handled or replaced with a more reliable service.

// Show all the weather data clearly on the screen.

// My main files are:

// src/App.tsx: user input and weather state

// src/components/LightningMap.tsx: Mapbox integration

// src/services/lightningService.ts: lightning + weather API

// 🔧 Fix any environment variable issues, incorrect fetch calls, and state mismanagement.

// Make sure everything works both locally and when deployed on Vercel.

// 💡 Also, improve UX where needed.

