import LightningTracker from '@/components/LightningTracker';

const Index = () => {
  return <LightningTracker />;
};

export default Index;
