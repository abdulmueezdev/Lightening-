# 🚀 Deployment Guide

This guide covers various deployment options for the Global Weather & Lightning Tracker dashboard.

## 📋 Pre-deployment Checklist

- [ ] Mapbox token configured
- [ ] Dependencies installed (`npm install`)
- [ ] Build successful (`npm run build`)
- [ ] No TypeScript errors (`npm run type-check`)
- [ ] No linting errors (`npm run lint`)

## 🌐 Deployment Options

### 1. Vercel (Recommended)

**Automatic Deployment:**
1. Connect your GitHub repository to Vercel
2. Import the project
3. Configure environment variables in Vercel Dashboard:
   - Go to your project settings
   - Navigate to "Environment Variables" tab
   - Add the following variables:
   ```
   VITE_OPENWEATHERMAP_API_KEY=your_openweathermap_api_key_here
   VITE_MAPBOX_API_KEY=your_mapbox_token_here
   ```
   - Optional variables:
   ```
   VITE_API_BASE_URL=https://api.example.com
   VITE_ENVIRONMENT=production
   ```
4. Deploy automatically on every push to main

**Environment Variable Setup in Vercel:**
- **Via Dashboard:**
  1. Go to [vercel.com](https://vercel.com) → Your Project → Settings
  2. Click "Environment Variables" in the sidebar
  3. Add each variable with name and value
  4. Select environments: Production, Preview, Development
  5. Save and redeploy

- **Via Vercel CLI:**
  ```bash
  vercel env add VITE_OPENWEATHERMAP_API_KEY
  vercel env add VITE_MAPBOX_API_KEY
  ```

**Manual Deployment:**
```bash
npm install -g vercel
vercel login

# Set environment variables
vercel env add VITE_OPENWEATHERMAP_API_KEY
vercel env add VITE_MAPBOX_API_KEY

# Deploy
vercel --prod
```

### 2. Netlify

**Via GitHub:**
1. Connect repository to Netlify
2. Build command: `npm run build`
3. Publish directory: `dist`
4. Add environment variables in site settings

**Manual Deployment:**
```bash
npm run build
# Drag and drop the 'dist' folder to Netlify
```

### 3. GitHub Pages

**Using GitHub Actions:**
1. Create `.github/workflows/deploy.yml`:
```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    
    - name: Install dependencies
      run: npm ci
    
    - name: Build
      run: npm run build
      env:
        VITE_OPENWEATHERMAP_API_KEY: ${{ secrets.VITE_OPENWEATHERMAP_API_KEY }}
        VITE_MAPBOX_API_KEY: ${{ secrets.VITE_MAPBOX_API_KEY }}
    
    - name: Deploy
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./dist
```

2. Add environment variables to repository secrets:
   - `VITE_OPENWEATHERMAP_API_KEY` 
   - `VITE_MAPBOX_API_KEY`
3. Enable Pages in repository settings

### 4. Docker Deployment

**Dockerfile:**
```dockerfile
# Build stage
FROM node:18-alpine as build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

# Production stage
FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

**nginx.conf:**
```nginx
server {
    listen 80;
    server_name localhost;
    root /usr/share/nginx/html;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://backend:3000;
    }
}
```

**Deploy commands:**
```bash
docker build -t weather-dashboard .
docker run -p 8080:80 weather-dashboard
```

### 5. AWS S3 + CloudFront

1. **Build the project:**
   ```bash
   npm run build
   ```

2. **Upload to S3:**
   ```bash
   aws s3 sync dist/ s3://your-bucket-name --delete
   ```

3. **Configure CloudFront distribution**
4. **Set up custom domain with Route 53**

## 🔧 Environment Configuration

### Required Environment Variables

```env
# Weather API Configuration
VITE_OPENWEATHERMAP_API_KEY=your_openweathermap_api_key_here

# Mapbox Configuration
VITE_MAPBOX_API_KEY=your_mapbox_token_here

# Optional Configuration
VITE_API_BASE_URL=https://api.example.com
VITE_ENVIRONMENT=production
```

**Getting API Keys:**
- **OpenWeatherMap API Key:**
  1. Visit [openweathermap.org/api](https://openweathermap.org/api)
  2. Create a free account
  3. Generate API key in your dashboard
  4. Free tier includes 1,000 calls/day

- **Mapbox Token:**
  1. Visit [mapbox.com](https://mapbox.com)
  2. Create a free account  
  3. Go to Account → Access Tokens
  4. Create new token or use default public token
  5. Free tier includes 50,000 requests/month

### Build Optimization

**For production builds:**
```bash
# Standard build
npm run build

# Development build (larger, with source maps)
npm run build:dev
```

## 🚨 Troubleshooting

### Common Issues

**1. Mapbox Token Issues**
- Ensure token is valid and has correct scopes
- Check token is properly set in environment variables
- Verify token format starts with `pk.`

**2. Build Failures**
- Clear node_modules: `rm -rf node_modules && npm install`
- Clear build cache: `rm -rf dist`
- Check Node.js version: `node --version` (should be 18+)

**3. Routing Issues (SPA)**
- Configure server for client-side routing
- Ensure all routes fallback to `index.html`

**4. Performance Issues**
- Enable gzip compression
- Configure proper caching headers
- Use CDN for static assets

### Build Size Optimization

```bash
# Analyze bundle size
npm install -g source-map-explorer
npm run build
npx source-map-explorer 'dist/assets/*.js'
```

## 📊 Monitoring & Analytics

### Performance Monitoring
- Google PageSpeed Insights
- Web Vitals measurement
- Lighthouse audits

### Error Tracking
- Sentry integration
- Console error monitoring
- User feedback collection

### Analytics
- Google Analytics 4
- Custom event tracking
- User behavior analysis

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    - run: npm ci
    - run: npm run lint
    - run: npm run type-check
    - run: npm run build

  deploy:
    needs: test
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
    - uses: actions/checkout@v3
    - uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
    - run: npm ci
    - run: npm run build
      env:
        VITE_OPENWEATHERMAP_API_KEY: ${{ secrets.VITE_OPENWEATHERMAP_API_KEY }}
        VITE_MAPBOX_API_KEY: ${{ secrets.VITE_MAPBOX_API_KEY }}
    - name: Deploy to Production
      run: |
        # Add your deployment commands here
        echo "Deploying to production..."
```

## 📱 Mobile App Deployment

### Progressive Web App (PWA)
- Configure service worker
- Add web app manifest
- Enable offline functionality
- App store submission ready

### Capacitor (Native Apps)
```bash
npm install @capacitor/core @capacitor/cli
npx cap init
npx cap add ios
npx cap add android
npx cap run ios
npx cap run android
```

## 🔐 Security Considerations

### Production Security
- HTTPS only deployment
- Content Security Policy headers
- Environment variable protection
- API rate limiting
- Input sanitization

### Security Headers
```nginx
add_header X-Frame-Options "SAMEORIGIN";
add_header X-Content-Type-Options "nosniff";
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains";
```

---

**Need help with deployment?** Check the [Issues](https://github.com/abdulmueezdev/storm-watch-sky/issues) or create a new issue with your deployment platform and error details.