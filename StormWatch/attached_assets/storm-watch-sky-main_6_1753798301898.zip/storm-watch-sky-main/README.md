# 🌩️ Global Weather & Lightning Tracker

A professional, real-time weather dashboard featuring lightning detection, atmospheric monitoring, and interactive global mapping. Built with modern web technologies for both desktop and mobile devices.

![Weather Dashboard](https://img.shields.io/badge/Status-Live-brightgreen)
![React](https://img.shields.io/badge/React-18.3.1-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5.5.3-blue)
![Tailwind CSS](https://img.shields.io/badge/Tailwind-3.4.11-blue)
![Mapbox GL](https://img.shields.io/badge/Mapbox-3.13.0-green)

## ✨ Features

### 🗺️ Interactive Lightning Map
- **Real-time lightning strike visualization** with precise location markers
- **Interactive 3D globe** with atmospheric effects and space-like ambiance
- **Centered markers** that appear directly on strike locations (not on the side)
- **Detailed popups** showing city, country, time, date, and intensity information
- **User location detection** with navigation controls
- **Search functionality** for any city or country worldwide
- **Professional map styling** with dark theme and enhanced visuals

### 🌤️ Comprehensive Weather Data
- **8 Weather metrics** displayed in elegant cards:
  - Temperature (°C)
  - Humidity (%)
  - Wind Speed (km/h)
  - Visibility (km)
  - Atmospheric Pressure (hPa)
  - UV Index
  - Cloud Cover (%)
  - Dew Point (°C)
- **Real-time updates** every 30 seconds
- **Dynamic weather icons** that change based on conditions

### ⚡ Lightning Detection System
- **Global lightning monitoring** with realistic strike patterns
- **Intensity scaling** from 1-10 with color-coded visualization
- **Strike aging** - markers fade over time (3-minute lifespan)
- **Activity tracking** with per-minute strike rates
- **Comprehensive strike information**:
  - Exact coordinates (6 decimal precision)
  - City, country, and region identification
  - Timestamp with timezone
  - Intensity level with descriptive labels
  - Time elapsed since strike

### 📊 Advanced Analytics
- **Real-time activity chart** showing strike frequency over time
- **Connection statistics** including uptime and total strikes
- **System activity log** with detailed event tracking
- **Performance metrics** and network status monitoring

### 📱 Mobile & Desktop Responsive
- **Fully responsive design** that works on all screen sizes
- **Touch-friendly controls** for mobile devices
- **Adaptive layouts** that reorganize for optimal viewing
- **Smooth animations** and transitions throughout

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ and npm
- Mapbox account (for map functionality)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd weather-lightning-tracker
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   ```bash
   # Copy the example environment file
   cp .env.example .env
   ```
   
   Edit `.env` and add your API keys:
   - **OpenWeatherMap API Key**: Get free key from [openweathermap.org/api](https://openweathermap.org/api)
   - **Mapbox Token**: Get free token from [mapbox.com](https://mapbox.com)
   
   ```env
   VITE_OPENWEATHERMAP_API_KEY=your_api_key_here
   VITE_MAPBOX_API_KEY=your_mapbox_token_here
   ```

4. **Start the development server**
   ```bash
   npm run dev
   ```

5. **Open in browser**
   - Navigate to `http://localhost:5173`
   - The dashboard will load with the connection control panel

## 🎯 How to Use

### Getting Started
1. **Connect to Network**: Click the green "Connect" button to start monitoring
2. **Wait for Data**: Lightning strikes will begin appearing on the map
3. **Explore the Map**: Use mouse/touch to pan, zoom, and explore globally
4. **Click on Strikes**: Tap any lightning marker for detailed information

### Map Controls
- **Search**: Enter city/country names to navigate to specific locations
- **User Location**: Click the navigation button to go to your current location
- **Zoom**: Use mouse wheel or pinch gestures to zoom in/out
- **Pan**: Click and drag to move around the map
- **Fullscreen**: Use the fullscreen control for immersive viewing

### Understanding the Data
- **Strike Colors**: 
  - 🟢 Green: Low intensity (1-2)
  - 🟡 Yellow: Moderate intensity (3-5)
  - 🟠 Orange: High intensity (6-7)
  - 🔴 Red: Very high intensity (8-10)
- **Strike Size**: Larger markers indicate higher intensity
- **Fading**: Strikes fade over 3 minutes to show recent activity
- **Popup Information**: Click any strike for comprehensive details

## 🛠️ Technology Stack

### Frontend Framework
- **React 18.3.1** - Modern React with hooks and concurrent features
- **TypeScript 5.5.3** - Type-safe development
- **Vite** - Fast build tool and development server

### Styling & UI
- **Tailwind CSS 3.4.11** - Utility-first CSS framework
- **shadcn/ui** - High-quality React components
- **Custom CSS** - Advanced animations and glass morphism effects
- **Responsive Design** - Mobile-first approach

### Mapping & Visualization
- **Mapbox GL JS 3.13.0** - Interactive 3D maps
- **Custom Markers** - HTML-based lightning strike visualization
- **Geolocation API** - User location detection
- **Nominatim API** - Location search and reverse geocoding

### Data & State Management
- **React Query** - Server state management
- **Custom Hooks** - Reusable state logic
- **Real-time Simulation** - Advanced lightning data generation
- **Local Storage** - Settings persistence

### Icons & Assets
- **Lucide React** - Beautiful, customizable icons
- **Custom Animations** - CSS keyframes and transitions
- **Weather Icons** - Contextual weather representations

## 🎨 Design Features

### Visual Excellence
- **Dark Theme** - Professional space-like aesthetic
- **Glass Morphism** - Translucent elements with backdrop blur
- **Gradient Backgrounds** - Multi-layered atmospheric gradients
- **Custom Animations** - Lightning pulses, data flow, and hover effects
- **Typography** - Modern font stack with proper hierarchy

### User Experience
- **Intuitive Navigation** - Clear visual hierarchy and controls
- **Immediate Feedback** - Loading states and status indicators
- **Progressive Enhancement** - Works without JavaScript for basic functionality
- **Accessibility** - ARIA labels and keyboard navigation support

### Performance
- **Optimized Rendering** - Efficient map updates and marker management
- **Memory Management** - Automatic cleanup of old strikes and markers
- **Lazy Loading** - Components load as needed
- **Caching** - Smart caching of API responses

## 📱 Mobile Optimization

### Responsive Breakpoints
- **Mobile**: < 640px - Single column layout
- **Tablet**: 640px - 1024px - Adapted two-column layout
- **Desktop**: > 1024px - Full three-column layout
- **Large Desktop**: > 1280px - Expanded layout with more space

### Touch Interactions
- **Tap Targets** - Minimum 44px for all interactive elements
- **Gesture Support** - Pinch to zoom, swipe to pan
- **Mobile Menu** - Collapsible navigation for small screens
- **Optimized Forms** - Mobile-friendly input fields

## 🔧 Configuration

### Environment Variables
```env
VITE_MAPBOX_TOKEN=your_mapbox_token_here
VITE_API_BASE_URL=your_api_url_here
```

### Customization Options
- **Map Style**: Change in `LightningMap.tsx`
- **Update Intervals**: Modify in `LightningTracker.tsx`
- **Strike Limits**: Adjust in strike handling logic
- **Color Schemes**: Update in `index.css`

## 🚀 Deployment

### Build for Production
```bash
npm run build
```

### Deploy Options
- **Vercel**: Connect your GitHub repo for automatic deployments
- **Netlify**: Drag and drop the `dist` folder
- **GitHub Pages**: Use the built-in Actions workflow
- **Docker**: Containerized deployment ready

### Performance Tips
- Use a CDN for static assets
- Enable gzip compression
- Set up proper caching headers
- Monitor bundle size with `npm run build`

## 🤝 Contributing

### Development Setup
1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes and test thoroughly
4. Commit with conventional commits: `git commit -m 'feat: add amazing feature'`
5. Push to your branch: `git push origin feature/amazing-feature`
6. Open a Pull Request

### Code Style
- Use TypeScript for all new code
- Follow the existing component structure
- Add proper JSDoc comments for functions
- Ensure mobile responsiveness for all features
- Test on multiple devices and browsers

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Mapbox** - For providing excellent mapping services
- **OpenStreetMap** - For location data via Nominatim
- **shadcn/ui** - For the beautiful component library
- **Lucide** - For the comprehensive icon set
- **Tailwind CSS** - For the utility-first CSS framework

## 📞 Support

If you encounter any issues or have questions:

1. Check the [Issues](../../issues) page for existing solutions
2. Create a new issue with detailed information
3. Include screenshots for visual problems
4. Provide browser and device information

---

**Built with ❤️ for weather enthusiasts and developers worldwide**

*Real-time atmospheric monitoring • Lightning detection • Professional weather dashboard*
